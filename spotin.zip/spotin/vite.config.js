import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// Change '/spotin/' to match your GitHub repo name exactly
// e.g. if your repo URL is github.com/yourname/parking-app → use '/parking-app/'
export default defineConfig({
  plugins: [react()],
  base: '/spotin/',
})
