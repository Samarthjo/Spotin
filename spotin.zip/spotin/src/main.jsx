import React from 'react'
import ReactDOM from 'react-dom/client'
import SpotIn from './SpotIn.jsx'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <SpotIn />
  </React.StrictMode>,
)
