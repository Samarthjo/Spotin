# SpotIn 🅿️
### Smart Parking Intelligence · India

> **₹240Cr ARR target · 50 cities · EBITDA+ Year 3**

A full interactive business plan for SpotIn — the real-time parking intelligence platform for urban India. Built as a React app with 9 deep-dive sections covering product architecture, business model, financials, funding strategy, and a week-by-week 90-day launch sprint.

---

## Sections

| Tab | Content |
|-----|---------|
| Overview | Problem analysis, first principles, India market timing |
| Product | 3-pillar platform: Consumer App · IoT Sensors · Operator SaaS |
| Business Model | 6 revenue streams, unit economics, dynamic pricing |
| Market & GTM | TAM/SAM/SOM, 4-phase city expansion, competitive matrix, 5 moats |
| Financials | 5-year projections (recharts), metrics table, path to profitability |
| Funding | 5-round roadmap, investor pitch angles, exit scenarios |
| 90-Day Sprint | Week-by-week execution plan, 12-hire sequence, milestone scorecard |
| Partnerships | Google Maps, Jio IoT, PhonePe, Smart City Mission, Mall operators |
| Risk Matrix | 8 risks scored by likelihood × impact, regulatory landscape, scenario planning |

---

## Run Locally

```bash
npm install
npm run dev
```

Open [http://localhost:5173](http://localhost:5173)

---

## Deploy to GitHub Pages

This repo auto-deploys via GitHub Actions on every push to `main`.

**One-time setup:**
1. Go to your repo → **Settings** → **Pages**
2. Under *Source*, select **GitHub Actions**
3. Push to `main` — the workflow handles the rest

**Live URL:** `https://<your-username>.github.io/spotin/`

> ⚠️ If your repo name is not `spotin`, update the `base` field in `vite.config.js` to match.

---

## Tech Stack

- **React 18** + **Vite 5**
- **Recharts** — financial projections charts
- **Inline styles** — no Tailwind/CSS-in-JS dependency
- **GitHub Actions** — zero-config CI/CD to GitHub Pages
